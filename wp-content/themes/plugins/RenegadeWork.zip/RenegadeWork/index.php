<?php

/*
 Plugin Name: Renegade Work
Plugin URI:
Description: Custom Post Type for Renegade Projects
Version: 1.0
Author: Anne Rothschild
Author URI:
*/
/********************************************************/
/*                CREATE ADMIN AREA                     */
/********************************************************/
$GLOBALS['RenegadePluginPath'] = plugins_url('/', __FILE__);


$pluginDIR = plugin_dir_path( __FILE__ );
//$renegade_project_icon = $pluginDIR . 'image/ic_admin_project.png';


/****************************************************************************************************************/
/*                                        CREATE THE CUSTOM POST TYPE                                           */
/****************************************************************************************************************/


add_action( 'init', 'create_project_post_type' );

function create_project_post_type() {
	
	$labels = array(
			'name'               => _x( 'Projects', 'post type general name', 'your-plugin-textdomain' ),
			'singular_name'      => _x( 'Project', 'post type singular name', 'your-plugin-textdomain' ),
			'menu_name'          => _x( 'Renegade Work', 'admin menu', 'your-plugin-textdomain' ),
			'name_admin_bar'     => _x( 'Project', 'add new on admin bar', 'your-plugin-textdomain' ),
			'add_new'            => _x( 'Add New', 'project', 'your-plugin-textdomain' ),
			'add_new_item'       => __( 'Add New Project', 'your-plugin-textdomain' ),
			'new_item'           => __( 'New Project', 'your-plugin-textdomain' ),
			'edit_item'          => __( 'Edit Project', 'your-plugin-textdomain' ),
			'view_item'          => __( 'View Project', 'your-plugin-textdomain' ),
			'all_items'          => __( 'All Projects', 'your-plugin-textdomain' ),
			//'search_items'       => __( 'Search Books', 'your-plugin-textdomain' ),
			//'parent_item_colon'  => __( 'Parent Books:', 'your-plugin-textdomain' ),
			'not_found'          => __( 'No projects found.', 'your-plugin-textdomain' ),
			'not_found_in_trash' => __( 'No projects found in Trash.', 'your-plugin-textdomain' )
	);
	
	$args = array(
			'labels' => $labels,
			'singular_label' => __('Project'),
			'public' => true,
			'show_ui' => true,
			'show_in_nav_menus' => false,
			'add_new_item' => __( 'Add New Project' ),
			'add_new' => __( 'Add New' ),
			'show_in_menu' => true,
			'menu_position' => 21,
		//	'taxonomies' => array('category', 'post_tag'),
			'show_in_admin_bar' => true,
			'capability_type' => 'post',
			//'register_meta_box_cb' => 'add_custom_meta_box',
			'hierarchical' => true,
			'rewrite' => true,
			'has_archive' => true,
			'supports' => array('title', 'custom_meta_fields', 'page_attributes')
	);

	register_post_type( 'projects' , $args );
}

/****************************************************************************************************************/
/*                              CREATE THE CUSTOM COLUMNS FOR THE POST TYPE                                      */
/****************************************************************************************************************/



//add_filter( 'manage_project_columns', 'set_custom_project_columns' );

add_filter("manage_projects_posts_columns", "add_new_project_columns");

function add_new_project_columns($columns) {
	unset(  $columns['author'], $columns['date']  );
	//$columns['project_name'] = 				__( 'Project Name', 'your_text_domain' );
	$columns['rw_logo'] = 				__( 'Logo', 'your_text_domain' );
	$columns['rw_caseStudies'] = 		__( 'Case Studies', 'your_text_domain' );
	$columns['rw_industry'] = 				__( 'Industry', 'your_text_domain' );
	$columns['rw_services'] = 				__( 'Services', 'your_text_domain' );
	//$columns['rw_blurb'] = 				__( 'Blurb', 'your_text_domain' );
	
	return $columns;
}

/****************************************************************************************************************/
/*                              MAKE COLUMN SORTABLE BY CLIENT NAME                                      */
/****************************************************************************************************************/
add_filter( 'manage_edit-projects_sortable_columns', 'sortable_rw_column' );

function sortable_rw_column( $rw_columns ) {
	$rw_columns['title'] = 'title';
	$rw_columns['rw_logo'] = 'rw_logo';
	$rw_columns['rw_caseStudies'] = 'rw_caseStudies';
	//To make a column 'un-sortable' remove it from the array
	//unset($bg_columns['date']);

	return $rw_columns;
}


/****************************************************************************************************************/
/*                              LOAD CLIENT DATA PREVIOUSLY ENTERED                                      */
/****************************************************************************************************************/

//add_action("manage_posts_custom_column",  "project_custom_columns");
add_action("manage_posts_custom_column", "project_custom_columns");

function project_custom_columns($rw_column){
	global $post;
	switch ($rw_column)
	{
				
		case "rw_logo":
			//$custom = get_post_custom();
			$RClogo= get_field('rw_logo');
			
			if( $RClogo ) {
				echo($RClogo);
			}
			break;
				
		case "rw_caseStudies":
			
			$RCcaseStudies = get_field('rw_caseStudies');
			
			if( $RCcaseStudies ) {
					echo($RCcaseStudies); 
			}
			break;
				
			case "rw_industry":
			$RCindustry = get_field('rw_industry');
				echo($RCindustry);
			break;
			
			case "rw_services":
				$RCurl = get_field('rw_url');
				if(  $RCservices ) {
					echo('<a href="' . $RCservices . '" target="_blank">' . $RCservices . '</a>');
				}
				break;


	}
}

/****************************************************************************************************************/
/*                              ADD EDIT LINKS TO CLIENT NAME COLUMN                                      */
/****************************************************************************************************************/




function rw_title_text_input ( $title ) {
	if ( get_post_type() == 'projects' ) {
		$title = __( 'Enter the project name here' );
	}
	return $title;
} // End title_text_input()
add_filter( 'enter_title_here', 'rw_title_text_input' );



/****************************************************************************************************************/
/*                              ADD TAXONOMY TO POST TYPE                                     */
/****************************************************************************************************************/


function rw_taxonomies() {

	$taxonomies = array(
		array(
			'slug'         => 'industry_verticals',
			'single_name'  => 'Industry Vertical',
			'plural_name'  => 'Industry Verticals',
			'post_type'    => 'projects',
			'rewrite'      => array( 'slug' => 'department' ),
		),
		array(
			'slug'         => 'service_types',
			'single_name'  => 'Service Type',
			'plural_name'  => 'Service Types',
			'post_type'    => 'projects',
			'hierarchical' => true,
		),
			
		array(
					'slug'         => 'clients',
					'single_name'  => 'Client',
					'plural_name'  => 'Clients',
					'post_type'    => 'projects',
					'hierarchical' => true,
			),
		
	);

	foreach( $taxonomies as $taxonomy ) {
		$labels = array(
			'name' => $taxonomy['plural_name'],
			'singular_name' => $taxonomy['single_name'],
			'search_items' =>  'Search ' . $taxonomy['plural_name'],
			'all_items' => 'All ' . $taxonomy['plural_name'],
			'parent_item' => 'Parent ' . $taxonomy['single_name'],
			'parent_item_colon' => 'Parent ' . $taxonomy['single_name'] . ':',
			'edit_item' => 'Edit ' . $taxonomy['single_name'],
			'update_item' => 'Update ' . $taxonomy['single_name'],
			'add_new_item' => 'Add New ' . $taxonomy['single_name'],
			'new_item_name' => 'New ' . $taxonomy['single_name'] . ' Name',
			'menu_name' => $taxonomy['plural_name']
		);
		
		$rewrite = isset( $taxonomy['rewrite'] ) ? $taxonomy['rewrite'] : array( 'slug' => $taxonomy['slug'] );
		$hierarchical = isset( $taxonomy['hierarchical'] ) ? $taxonomy['hierarchical'] : true;
	
		register_taxonomy( $taxonomy['slug'], $taxonomy['post_type'], array(
			'hierarchical' => $hierarchical,
			'labels' => $labels,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => $rewrite,
		));
	}
	
	//ADD ABILITIY TO ASSIGN A CATEGORY TO AN IMAGE ATTACHMENT
	
	register_taxonomy_for_object_type( 'category', 'attachments' );
}
add_action( 'init', 'rw_taxonomies' );